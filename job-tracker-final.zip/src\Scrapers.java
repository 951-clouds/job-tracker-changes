import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Real source adapters. Each adapter maps only fields exposed by the source. */
final class Scrapers {
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private Scrapers() {}

    static List<Map<String, Object>> fetch(String sourceId) throws IOException, InterruptedException {
        if ("remotive".equals(sourceId)) return fetchRemotive();
        if ("amazon".equals(sourceId)) return fetchAmazon();
        throw new IllegalArgumentException("未知岗位来源: " + sourceId);
    }

    private static List<Map<String, Object>> fetchRemotive() throws IOException, InterruptedException {
        String url = "https://remotive.com/api/remote-jobs?limit=80";
        Json.Obj response = getJson(url);
        List<Map<String, Object>> result = new ArrayList<>();
        Object jobsValue = response.get("jobs");
        if (!(jobsValue instanceof List<?>)) throw new IOException("Remotive 返回格式异常：缺少 jobs 数组");
        for (Object value : (List<?>) jobsValue) {
            if (!(value instanceof Map<?, ?>)) continue;
            Json.Obj raw = Json.asObj(value);
            String id = Json.text(raw, "id");
            String title = trim(Json.text(raw, "title"));
            String jobUrl = trim(Json.text(raw, "url"));
            if (id == null || title == null || jobUrl == null) continue;
            String description = cleanHtml(Json.text(raw, "description"));
            String requirements = description;
            Json.Obj job = Json.obj()
                    .set("stableId", id)
                    .set("title", title)
                    .set("company", trim(Json.text(raw, "company_name")))
                    .set("city", trim(Json.text(raw, "candidate_required_location")))
                    .set("location", trim(Json.text(raw, "candidate_required_location")))
                    .set("requirements", requirements)
                    .set("description", description)
                    .set("deadline", explicitDeadline(raw))
                    .set("status", explicitStatus(raw))
                    .set("url", jobUrl)
                    .set("postedAt", trim(Json.text(raw, "publication_date")))
                    .set("jobType", trim(Json.text(raw, "job_type")))
                    .set("category", trim(Json.text(raw, "category")))
                    .set("salary", trim(Json.text(raw, "salary")))
                    .set("sourceUpdatedAt", trim(Json.text(raw, "publication_date")));
            result.add(job);
        }
        return result;
    }
    private static List<Map<String, Object>> fetchAmazon() throws IOException, InterruptedException {
        String url = "https://www.amazon.jobs/en/search.json?base_query=software&result_limit=50&sort=recent&offset=0";
        Json.Obj response = getJson(url);
        List<Map<String, Object>> result = new ArrayList<>();
        Object jobsValue = response.get("jobs");
        if (!(jobsValue instanceof List<?>)) throw new IOException("Amazon Jobs 返回格式异常：缺少 jobs 数组");
        for (Object value : (List<?>) jobsValue) {
            if (!(value instanceof Map<?, ?>)) continue;
            Json.Obj raw = Json.asObj(value);
            String id = firstNonBlank(Json.text(raw, "id_icims"), Json.text(raw, "id"));
            String title = trim(Json.text(raw, "title"));
            String path = trim(Json.text(raw, "job_path"));
            if (id == null || title == null || path == null) continue;
            String description = cleanHtml(Json.text(raw, "description"));
            String required = cleanHtml(Json.text(raw, "basic_qualifications"));
            String preferred = cleanHtml(Json.text(raw, "preferred_qualifications"));
            String requirements = joinNonBlank("\n\n", required, preferred);
            String jobUrl = path.startsWith("http") ? path : "https://www.amazon.jobs" + (path.startsWith("/") ? path : "/" + path);
            Json.Obj job = Json.obj()
                    .set("stableId", id)
                    .set("title", title)
                    .set("company", firstNonBlank(Json.text(raw, "company_name"), "Amazon"))
                    .set("city", trim(Json.text(raw, "city")))
                    .set("location", firstNonBlank(Json.text(raw, "location"), Json.text(raw, "city")))
                    .set("requirements", requirements)
                    .set("description", description)
                    .set("deadline", explicitDeadline(raw))
                    .set("status", explicitStatus(raw))
                    .set("url", jobUrl)
                    .set("postedAt", firstNonBlank(Json.text(raw, "posted_date"), Json.text(raw, "postedDate")))
                    .set("jobType", trim(Json.text(raw, "job_schedule_type")))
                    .set("category", firstNonBlank(Json.text(raw, "job_category"), Json.text(raw, "job_family")))
                    .set("salary", null)
                    .set("sourceUpdatedAt", trim(Json.text(raw, "updated_time")));
            result.add(job);
        }
        return result;
    }
    private static Json.Obj getJson(String url) throws IOException, InterruptedException {
        IOException last = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(45))
                        .header("User-Agent", "JobTrackerLocal/1.0 (personal job search)")
                        .header("Accept", "application/json,text/plain,*/*")
                        .GET()
                        .build();
                HttpResponse<byte[]> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofByteArray());
                String body = new String(response.body(), StandardCharsets.UTF_8);
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    try { return Json.asObj(Json.parse(body)); }
                    catch (IllegalArgumentException ex) { throw new IOException("来源返回的不是有效 JSON: " + ex.getMessage(), ex); }
                }
                String message = "来源请求失败（HTTP " + response.statusCode() + "）";
                if (response.statusCode() == 429 || response.statusCode() >= 500) {
                    last = new IOException(message);
                    if (attempt < 3) { Thread.sleep(900L * attempt); continue; }
                }
                throw new IOException(message + ": " + abbreviate(cleanHtml(body), 180));
            } catch (IOException ex) {
                last = ex;
                if (attempt < 3) { Thread.sleep(900L * attempt); continue; }
            }
        }
        throw last == null ? new IOException("来源请求失败") : last;
    }

    private static String explicitDeadline(Json.Obj raw) {
        String[] keys = {"deadline", "closing_date", "closingDate", "application_deadline", "applicationDeadline", "expiration_date"};
        for (String key : keys) {
            Object value = raw.get(key);
            if (value == null) continue;
            if (value instanceof Boolean) return (Boolean) value ? "explicit" : "closed";
            String text = trim(String.valueOf(value));
            if (text != null) return text;
        }
        return null;
    }

    private static String explicitStatus(Json.Obj raw) {
        Object status = firstPresent(raw, "status", "job_status", "jobStatus", "posting_status");
        if (status != null) {
            String text = trim(String.valueOf(status));
            if (text != null) return normalizeStatus(text);
        }
        Object closed = firstPresent(raw, "is_closed", "isClosed");
        if (closed instanceof Boolean) return (Boolean) closed ? "closed" : "open";
        Object active = firstPresent(raw, "is_active", "isActive");
        if (active instanceof Boolean) return (Boolean) active ? "open" : "closed";
        return null;
    }

    private static Object firstPresent(Json.Obj raw, String... keys) {
        for (String key : keys) if (raw.containsKey(key) && raw.get(key) != null) return raw.get(key);
        return null;
    }

    private static String normalizeStatus(String raw) {
        String lower = raw.toLowerCase(Locale.ROOT).trim();
        if (lower.equals("closed") || lower.equals("inactive") || lower.equals("expired") || lower.equals("filled") || lower.equals("removed")) return "closed";
        if (lower.equals("open") || lower.equals("active") || lower.equals("available") || lower.equals("published")) return "open";
        return raw;
    }

    private static String cleanHtml(String input) {
        if (input == null) return null;
        String text = input.replaceAll("(?is)<br\\s*/?>", "\n")
                .replaceAll("(?is)</p\\s*>", "\n")
                .replaceAll("(?is)<li[^>]*>", "\n- ")
                .replaceAll("(?is)<[^>]+>", " ")
                .replace("\u00a0", " ");
        text = decodeEntities(text);
        text = text.replaceAll("[\\t\\x0B\\f\\r]+", " ")
                .replaceAll(" *\\n *", "\n")
                .replaceAll("\\n{3,}", "\n\n")
                .replaceAll("[ ]{2,}", " ");
        return trim(text);
    }

    private static String decodeEntities(String text) {
        String value = text.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
                .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'");
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == '&' && i + 3 < value.length() && value.charAt(i + 1) == '#') {
                int end = value.indexOf(';', i + 2);
                if (end > i + 2 && end - i <= 9) {
                    String number = value.substring(i + 2, end);
                    try {
                        int code = number.startsWith("x") || number.startsWith("X") ? Integer.parseInt(number.substring(1), 16) : Integer.parseInt(number);
                        out.appendCodePoint(code);
                        i = end;
                        continue;
                    } catch (Exception ignored) {}
                }
            }
            out.append(c);
        }
        return out.toString();
    }

    private static String joinNonBlank(String separator, String... values) {
        List<String> parts = new ArrayList<>();
        for (String value : values) if (trim(value) != null) parts.add(value.trim());
        return parts.isEmpty() ? null : String.join(separator, parts);
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) if (trim(value) != null) return value.trim();
        return null;
    }

    private static String trim(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        return trimmed.isEmpty() || "null".equalsIgnoreCase(trimmed) ? null : trimmed;
    }

    private static String abbreviate(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, max) + "...";
    }
}
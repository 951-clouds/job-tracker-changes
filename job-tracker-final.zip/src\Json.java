import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Small dependency-free JSON parser/serializer used by the local job tracker. */
final class Json {
    private Json() {}

    static Obj obj() { return new Obj(); }
    static Arr arr() { return new Arr(); }
    static Arr arr(Object... values) { Arr a = new Arr(); for (Object value : values) a.add(value); return a; }

    static Object parse(String text) {
        if (text == null) throw new IllegalArgumentException("JSON 内容不能为空");
        Parser parser = new Parser(text);
        Object value = parser.readValue();
        parser.skipWhitespace();
        if (!parser.atEnd()) throw parser.error("JSON 结尾存在多余内容");
        return value;
    }

    static String stringify(Object value) { StringBuilder sb = new StringBuilder(); write(value, sb); return sb.toString(); }

    @SuppressWarnings("unchecked")
    static Obj asObj(Object value) {
        if (!(value instanceof Map<?, ?>)) throw new IllegalArgumentException("需要 JSON 对象");
        return (Obj) value;
    }

    @SuppressWarnings("unchecked")
    static Arr asArr(Object value) {
        if (!(value instanceof List<?>)) throw new IllegalArgumentException("需要 JSON 数组");
        return (Arr) value;
    }

    static String text(Map<String, Object> map, String key) {
        if (map == null) return null;
        Object value = map.get(key);
        return value == null ? null : String.valueOf(value);
    }

    static String text(Object value) { return value == null ? null : String.valueOf(value); }

    static int integer(Map<String, Object> map, String key, int fallback) {
        Object value = map == null ? null : map.get(key);
        if (value instanceof Number) return ((Number) value).intValue();
        if (value != null) { try { return Integer.parseInt(String.valueOf(value)); } catch (NumberFormatException ignored) {} }
        return fallback;
    }

    static long longValue(Map<String, Object> map, String key, long fallback) {
        Object value = map == null ? null : map.get(key);
        if (value instanceof Number) return ((Number) value).longValue();
        if (value != null) { try { return Long.parseLong(String.valueOf(value)); } catch (NumberFormatException ignored) {} }
        return fallback;
    }

    static boolean bool(Map<String, Object> map, String key, boolean fallback) {
        Object value = map == null ? null : map.get(key);
        if (value instanceof Boolean) return (Boolean) value;
        if (value != null) return Boolean.parseBoolean(String.valueOf(value));
        return fallback;
    }
    private static void write(Object value, StringBuilder sb) {
        if (value == null) {
            sb.append("null");
        } else if (value instanceof String || value instanceof Character || value instanceof Enum<?>) {
            writeString(String.valueOf(value), sb);
        } else if (value instanceof Boolean) {
            sb.append(value);
        } else if (value instanceof BigDecimal) {
            sb.append(((BigDecimal) value).toPlainString());
        } else if (value instanceof BigInteger) {
            sb.append(value);
        } else if (value instanceof Number) {
            double d = ((Number) value).doubleValue();
            if (!Double.isFinite(d)) throw new IllegalArgumentException("不能序列化非有限数字");
            sb.append(value);
        } else if (value instanceof Map<?, ?>) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) value).entrySet()) {
                if (!first) sb.append(',');
                first = false;
                writeString(String.valueOf(entry.getKey()), sb);
                sb.append(':');
                write(entry.getValue(), sb);
            }
            sb.append('}');
        } else if (value instanceof Iterable<?>) {
            sb.append('[');
            boolean first = true;
            for (Object item : (Iterable<?>) value) {
                if (!first) sb.append(',');
                first = false;
                write(item, sb);
            }
            sb.append(']');
        } else if (value.getClass().isArray()) {
            sb.append('[');
            int length = java.lang.reflect.Array.getLength(value);
            for (int i = 0; i < length; i++) {
                if (i > 0) sb.append(',');
                write(java.lang.reflect.Array.get(value, i), sb);
            }
            sb.append(']');
        } else {
            writeString(String.valueOf(value), sb);
        }
    }

    private static void writeString(String value, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
    }

    static final class Obj extends LinkedHashMap<String, Object> {
        Obj set(String key, Object value) { put(key, value); return this; }
        Obj setAll(Map<String, Object> values) { if (values != null) putAll(values); return this; }
        Obj removeNulls() { entrySet().removeIf(entry -> entry.getValue() == null); return this; }

        Obj copy() {
            Obj copy = new Obj();
            for (Map.Entry<String, Object> entry : entrySet()) copy.put(entry.getKey(), deepCopy(entry.getValue()));
            return copy;
        }
    }

    static final class Arr extends ArrayList<Object> {
        Arr addAllItems(Collection<?> values) { if (values != null) addAll(values); return this; }

        Arr copy() {
            Arr copy = new Arr();
            for (Object value : this) copy.add(deepCopy(value));
            return copy;
        }
    }

    @SuppressWarnings("unchecked")
    static Object deepCopy(Object value) {
        if (value instanceof Map<?, ?>) return new Obj().setAll((Map<String, Object>) value).copy();
        if (value instanceof List<?>) {
            Arr copy = new Arr();
            for (Object item : (List<?>) value) copy.add(deepCopy(item));
            return copy;
        }
        return value;
    }
    private static final class Parser {
        private final String text;
        private int index;

        Parser(String text) { this.text = text; }
        boolean atEnd() { return index >= text.length(); }

        void skipWhitespace() {
            while (!atEnd()) {
                char c = text.charAt(index);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') index++;
                else break;
            }
        }

        Object readValue() {
            skipWhitespace();
            if (atEnd()) throw error("缺少 JSON 值");
            char c = text.charAt(index);
            if (c == '{') return readObject();
            if (c == '[') return readArray();
            if (c == '"') return readString();
            if (c == 't') { expectWord("true"); return Boolean.TRUE; }
            if (c == 'f') { expectWord("false"); return Boolean.FALSE; }
            if (c == 'n') { expectWord("null"); return null; }
            if (c == '-' || (c >= '0' && c <= '9')) return readNumber();
            throw error("无法识别的 JSON 值");
        }

        private Obj readObject() {
            Obj object = new Obj();
            index++;
            skipWhitespace();
            if (peek('}')) { index++; return object; }
            while (true) {
                skipWhitespace();
                if (!peek('"')) throw error("对象键必须是字符串");
                String key = readString();
                skipWhitespace();
                expect(':');
                Object value = readValue();
                object.put(key, value);
                skipWhitespace();
                if (peek('}')) { index++; return object; }
                expect(',');
            }
        }

        private Arr readArray() {
            Arr array = new Arr();
            index++;
            skipWhitespace();
            if (peek(']')) { index++; return array; }
            while (true) {
                array.add(readValue());
                skipWhitespace();
                if (peek(']')) { index++; return array; }
                expect(',');
            }
        }

        private String readString() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (!atEnd()) {
                char c = text.charAt(index++);
                if (c == '"') return sb.toString();
                if (c != '\\') {
                    if (c < 0x20) throw error("字符串中包含控制字符");
                    sb.append(c);
                    continue;
                }
                if (atEnd()) throw error("字符串转义不完整");
                char escaped = text.charAt(index++);
                switch (escaped) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (index + 4 > text.length()) throw error("Unicode 转义不完整");
                        String hex = text.substring(index, index + 4);
                        try { sb.append((char) Integer.parseInt(hex, 16)); }
                        catch (NumberFormatException ex) { throw error("Unicode 转义无效"); }
                        index += 4;
                        break;
                    default: throw error("未知字符串转义");
                }
            }
            throw error("字符串未关闭");
        }
        private Number readNumber() {
            int start = index;
            if (peek('-')) index++;
            if (peek('0')) index++;
            else readDigits();
            boolean decimal = false;
            if (peek('.')) { decimal = true; index++; readDigits(); }
            if (peek('e') || peek('E')) { decimal = true; index++; if (peek('+') || peek('-')) index++; readDigits(); }
            String number = text.substring(start, index);
            try {
                if (decimal) return new BigDecimal(number);
                try { return Long.valueOf(number); }
                catch (NumberFormatException ignored) { return new BigInteger(number); }
            } catch (NumberFormatException ex) {
                throw error("数字格式无效");
            }
        }

        private void readDigits() {
            int start = index;
            while (!atEnd()) {
                char c = text.charAt(index);
                if (c >= '0' && c <= '9') index++;
                else break;
            }
            if (start == index) throw error("数字格式无效");
        }

        private void expectWord(String word) {
            if (!text.startsWith(word, index)) throw error("JSON 字面量无效");
            index += word.length();
        }

        private void expect(char expected) {
            skipWhitespace();
            if (atEnd() || text.charAt(index) != expected) throw error("需要字符 " + expected);
            index++;
        }

        private boolean peek(char c) { return !atEnd() && text.charAt(index) == c; }

        IllegalArgumentException error(String message) {
            return new IllegalArgumentException(message + "，位置 " + index);
        }
    }
}
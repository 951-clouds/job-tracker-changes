(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const state = {
    token: localStorage.getItem('jobtracker_token') || '',
    user: null,
    sources: [],
    cities: [],
    jobs: [],
    filters: [],
    changes: [],
    bootstrap: { totalJobs: 0, watchedCount: 0, unreadChanges: 0, lastSuccessfulScrapeAt: null },
    view: 'jobs',
    query: '',
    city: '',
    source: '',
    watchedOnly: false,
    loading: false
  };

  const FIELD_LABELS = { requirements: '岗位要求', deadline: '截止时间', status: '招聘状态' };
  const STATUS_LABELS = { closed: '已关闭', open: '招聘中', active: '招聘中', inactive: '已关闭', expired: '已关闭', removed: '已下架' };

  async function api(path, options = {}) {
    const headers = Object.assign({}, options.headers || {});
    const body = options.body;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (state.token) headers.Authorization = `Bearer ${state.token}`;
    const response = await fetch(path, {
      method: options.method || 'GET',
      headers,
      body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body))
    });
    const text = await response.text();
    let payload = null;
    try { payload = text ? JSON.parse(text) : null; } catch (_) { payload = { error: text }; }
    if (!response.ok) {
      if (response.status === 401) signOut(false);
      const error = new Error(payload && payload.error ? payload.error : `请求失败 (${response.status})`);
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  }

  function bindEvents() {
    $('#authToggle').addEventListener('click', toggleAuthMode);
    $('#authForm').addEventListener('submit', submitAuth);
    $('#logoutBtn').addEventListener('click', () => signOut(true));
    $('#mainNav').addEventListener('click', event => {
      const button = event.target.closest('[data-view]');
      if (!button) return;
      switchView(button.dataset.view);
    });
    $('#searchBtn').addEventListener('click', applySearch);
    $('#resetSearchBtn').addEventListener('click', resetSearch);
    $('#globalSearch').addEventListener('keydown', event => { if (event.key === 'Enter') applySearch(); });
    $('#cityFilter').addEventListener('change', applySearch);
    $('#sourceFilter').addEventListener('change', applySearch);
    $('#saveFilterBtn').addEventListener('click', () => openFilterDialog(null));
    $('#refreshBtn').addEventListener('click', () => scrapeSelected(null));
    $('#viewRoot').addEventListener('click', handleViewAction);
    $('#modalRoot').addEventListener('click', handleModalAction);
    $('#modalRoot').addEventListener('submit', handleModalSubmit);
    window.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
  }

  let authMode = 'register';
  function toggleAuthMode() {
    authMode = authMode === 'register' ? 'login' : 'register';
    const register = authMode === 'register';
    $('#authTitle').textContent = register ? '创建账号' : '登录账号';
    $('#authHint').textContent = register ? '账号用于隔离筛选方案、关注记录和岗位动态。' : '再次登录后可继续使用已保存的条件和关注列表。';
    $('#displayNameLabel').hidden = !register;
    $('#authSubmit').textContent = register ? '创建并进入' : '登录';
    $('#authToggle').textContent = register ? '已有账号？直接登录' : '没有账号？现在创建';
    $('#authError').textContent = '';
  }

  async function submitAuth(event) {
    event.preventDefault();
    const errorBox = $('#authError');
    errorBox.textContent = '';
    const body = { username: $('#username').value.trim(), password: $('#password').value };
    if (authMode === 'register') body.displayName = $('#displayName').value.trim();
    $('#authSubmit').disabled = true;
    $('#authSubmit').textContent = '处理中…';
    try {
      const result = await api(authMode === 'register' ? '/api/auth/register' : '/api/auth/login', { method: 'POST', body });
      state.token = result.user.token;
      localStorage.setItem('jobtracker_token', state.token);
      state.user = result.user;
      state.sources = result.sources || [];
      await enterApp();
    } catch (error) {
      errorBox.textContent = error.message;
    } finally {
      $('#authSubmit').disabled = false;
      $('#authSubmit').textContent = authMode === 'register' ? '创建并进入' : '登录';
    }
  }

  async function signOut(notify) {
    if (notify && state.token) {
      try { await api('/api/auth/logout', { method: 'POST' }); } catch (_) {}
    }
    state.token = '';
    state.user = null;
    localStorage.removeItem('jobtracker_token');
    $('#appShell').hidden = true;
    $('#authScreen').hidden = false;
    closeModal();
    if (notify) toast('已退出登录');
  }

  async function enterApp() {
    $('#authScreen').hidden = true;
    $('#appShell').hidden = false;
    await refreshBootstrap();
    await loadViewData();
    renderChrome();
    renderView();
  }

  async function refreshBootstrap() {
    state.bootstrap = await api('/api/bootstrap');
    state.user = state.bootstrap.user;
    state.sources = state.bootstrap.sources || [];
    state.cities = state.bootstrap.cities || [];
  }

  async function loadViewData() {
    if (state.view === 'jobs' || state.view === 'watched') {
      state.watchedOnly = state.view === 'watched';
      const params = new URLSearchParams();
      if (state.query) params.set('q', state.query);
      if (state.city) params.set('city', state.city);
      if (state.source) params.set('source', state.source);
      if (state.watchedOnly) params.set('watched', '1');
      const result = await api(`/api/jobs?${params.toString()}`);
      state.jobs = result.jobs || [];
      state.cities = result.cities || state.cities;
    } else if (state.view === 'filters') {
      state.filters = (await api('/api/filters')).filters || [];
    } else if (state.view === 'changes') {
      state.changes = (await api('/api/changes')).changes || [];
    }
  }

  async function switchView(view) {
    state.view = view;
    try {
      await loadViewData();
      renderChrome();
      renderView();
    } catch (error) { toast(error.message, true); }
  }

  function applySearch() {
    state.query = $('#globalSearch').value.trim();
    state.city = $('#cityFilter').value;
    state.source = $('#sourceFilter').value;
    switchView('jobs');
  }

  function resetSearch() {
    $('#globalSearch').value = '';
    $('#cityFilter').value = '';
    $('#sourceFilter').value = '';
    state.query = '';
    state.city = '';
    state.source = '';
    switchView('jobs');
  }
  function renderChrome() {
    document.querySelectorAll('#mainNav .nav-item').forEach(button => button.classList.toggle('active', button.dataset.view === state.view));
    $('#jobsNavCount').textContent = state.bootstrap.totalJobs || 0;
    $('#watchedNavCount').textContent = state.bootstrap.watchedCount || 0;
    $('#changesNavCount').textContent = state.bootstrap.unreadChanges || 0;
    const city = $('#cityFilter');
    city.innerHTML = '<option value="">全部城市</option>' + state.cities.map(value => `<option value="${esc(value)}">${esc(value)}</option>`).join('');
    city.value = state.city;
    $('#globalSearch').value = state.query;
    $('#sourceFilter').value = state.source;
    $('#userName').textContent = state.user ? (state.user.displayName || state.user.username) : '—';
    const enabled = state.user && state.user.selectedSources ? state.user.selectedSources.length : 0;
    $('#userMeta').textContent = `@${state.user ? state.user.username : ''} · ${enabled} 个来源`;
    $('#lastScrapeText').textContent = state.bootstrap.lastSuccessfulScrapeAt ? `最近采集 ${formatDateTime(state.bootstrap.lastSuccessfulScrapeAt)}` : '尚未采集';
  }

  function renderView() {
    if (state.view === 'jobs' || state.view === 'watched') renderJobsView();
    else if (state.view === 'filters') renderFiltersView();
    else if (state.view === 'changes') renderChangesView();
    else renderSourcesView();
  }

  function renderJobsView() {
    const isWatched = state.view === 'watched';
    const heading = isWatched ? '关注岗位' : '岗位库';
    const subtitle = isWatched ? '这里只显示当前账号关注中的岗位。取消关注后，历史动态仍会保留。' : '关键词匹配岗位名称或岗位要求；城市按选定值精确匹配。';
    const stats = `
      <div class="stats-row">
        <div class="stat-card"><b>${state.bootstrap.totalJobs || 0}</b><span>已采集岗位</span></div>
        <div class="stat-card"><b>${state.bootstrap.watchedCount || 0}</b><span>关注中</span></div>
        <div class="stat-card"><b>${state.bootstrap.unreadChanges || 0}</b><span>未读动态</span></div>
        <div class="stat-card"><b>${(state.sources || []).filter(source => (state.user.selectedSources || []).includes(source.id)).length}</b><span>启用来源</span></div>
      </div>`;
    let body;
    if ((state.bootstrap.totalJobs || 0) === 0) {
      body = `<div class="empty-state"><div class="empty-icon">↓</div><h2>还没有岗位数据</h2><p>请先选择一个或多个来源并执行采集。系统会使用“来源 + 稳定岗位 ID”识别岗位，首次采集只建立初始数据。</p><button class="primary" data-action="scrape">采集已启用来源</button> <button class="secondary" data-action="go-sources">管理来源</button></div>`;
    } else if (!state.jobs.length) {
      body = `<div class="empty-state"><div class="empty-icon">⌕</div><h2>没有符合条件的岗位</h2><p>关键词和城市会同时生效。可以修改条件，或回到岗位库查看全部数据。</p><button class="secondary" data-action="reset-search">清空筛选条件</button></div>`;
    } else {
      body = `<div class="job-list">${state.jobs.map(renderJobCard).join('')}</div>`;
    }
    $('#viewRoot').innerHTML = `${stats}<div class="page-head"><div><h1>${heading}</h1><p>${subtitle}</p></div><span class="badge">显示 ${state.jobs.length} 条</span></div>${body}`;
  }

  function renderJobCard(job) {
    const watched = !!job.watched;
    return `<article class="job-card">
      <div class="job-card-top">
        <div><h2 class="job-title">${esc(job.title || '未命名岗位')}</h2><p class="job-company">${esc(job.company || '公司未提供')}</p></div>
        <div class="job-badges">
          ${watched ? '<span class="badge watched">已关注</span>' : ''}
          <span class="badge ${job.sourceId === 'amazon' ? 'official' : 'source'}">${esc(job.sourceName || job.sourceId)}</span>
          <span class="badge ${String(job.status || '').toLowerCase() === 'closed' ? 'closed' : ''}">${esc(displayStatus(job.status))}</span>
        </div>
      </div>
      <div class="meta-row">
        <span>城市：${esc(displayValue(job.city))}</span>
        <span>截止：${esc(displayValue(job.deadline))}</span>
        <span>抓取：${esc(formatDateTime(job.lastFetchedAt))}</span>
      </div>
      <p class="requirements-preview">${esc(excerpt(job.requirements || job.description || '未提供'))}</p>
      <div class="card-actions">
        <div><a class="link" href="${safeUrl(job.url)}" target="_blank" rel="noopener">原始岗位链接 ↗</a></div>
        <div>
          <button class="secondary" data-action="open-job" data-key="${escAttr(job.jobKey)}">查看详情</button>
          <button class="${watched ? 'danger-button' : 'primary'}" data-action="toggle-watch" data-key="${escAttr(job.jobKey)}" data-watched="${watched}">${watched ? '取消关注' : '关注岗位'}</button>
        </div>
      </div>
    </article>`;
  }

  function renderFiltersView() {
    const cards = state.filters.length ? state.filters.map(filter => `<article class="filter-card">
      <h3>${esc(filter.name)}</h3>
      <p>使用方案时会根据当前岗位数据重新计算，不会自动推送新岗位。</p>
      <div class="conditions">
        ${filter.keyword ? `<span class="badge">关键词：${esc(filter.keyword)}</span>` : '<span class="badge">关键词：不限</span>'}
        ${filter.city ? `<span class="badge">城市：${esc(filter.city)}</span>` : '<span class="badge">城市：不限</span>'}
      </div>
      <div class="actions">
        <button class="ghost" data-action="edit-filter" data-id="${escAttr(filter.id)}">修改</button>
        <button class="danger-button" data-action="delete-filter" data-id="${escAttr(filter.id)}">删除</button>
        <button class="primary" data-action="use-filter" data-id="${escAttr(filter.id)}">使用</button>
      </div>
    </article>`).join('') : `<div class="empty-state"><div class="empty-icon">☆</div><h2>还没有筛选方案</h2><p>先设置关键词和城市，再把当前条件保存成有名称的方案，之后可以反复使用。</p></div>`;
    $('#viewRoot').innerHTML = `<div class="page-head"><div><h1>筛选方案</h1><p>保存常用的关键词与城市组合，使用时按当前已采集岗位重新计算。</p></div><button class="primary" data-action="new-filter">新建方案</button></div><div class="filter-grid">${cards}</div>`;
  }
  function renderChangesView() {
    if (!state.changes.length) {
      const noJobs = (state.bootstrap.totalJobs || 0) === 0;
      $('#viewRoot').innerHTML = `<div class="page-head"><div><h1>关注动态</h1><p>这里仅显示关注期间发生的岗位要求、截止时间和招聘状态变化。</p></div></div><div class="empty-state"><div class="empty-icon">↻</div><h2>${noJobs ? '先采集岗位再关注' : '暂时没有关注动态'}</h2><p>${noJobs ? '首次采集只建立初始数据；关注后再刷新来源，系统才会比较变化。' : '再次刷新来源后，如果关注岗位的岗位要求、截止时间或招聘状态发生变化，会出现在这里。'}</p>${noJobs ? '<button class="primary" data-action="scrape">采集已启用来源</button>' : ''}</div>`;
      return;
    }
    const unread = state.changes.filter(change => !change.seen).length;
    const cards = state.changes.map(change => {
      const job = change.job || {};
      return `<article class="change-card ${change.seen ? '' : 'unread'}" data-action="open-change" data-key="${escAttr(change.jobKey)}" data-id="${escAttr(change.id)}">
        <div><span class="change-field">${esc(FIELD_LABELS[change.field] || change.field)}</span></div>
        <div class="change-main">
          <h3>${esc(job.title || '岗位已不在当前列表')}</h3>
          <p>${esc(job.company || '')}${job.city ? ` · ${esc(job.city)}` : ''} · ${esc(job.sourceName || '')}</p>
          <div class="diff">
            <div class="diff-row"><b>原值</b><span class="diff-value old" title="${escAttr(displayChangeValue(change.field, change.oldValue))}">${esc(displayChangeValue(change.field, change.oldValue))}</span></div>
            <div class="diff-row"><b>新值</b><span class="diff-value new" title="${escAttr(displayChangeValue(change.field, change.newValue))}">${esc(displayChangeValue(change.field, change.newValue))}</span></div>
          </div>
        </div>
        <div class="change-time">${esc(formatDateTime(change.changedAt))}<br>${change.seen ? '已读' : '未读'}</div>
      </article>`;
    }).join('');
    $('#viewRoot').innerHTML = `<div class="page-head"><div><h1>关注动态</h1><p>关注前和取消关注后的变化不会补发；已有历史动态会保留。</p></div><button class="secondary" data-action="mark-all-seen" ${unread ? '' : 'disabled'}>全部标记已读</button></div><div class="change-list">${cards}</div>`;
  }

  function renderSourcesView() {
    const enabled = new Set(state.user.selectedSources || []);
    const cards = state.sources.map(source => `<article class="source-card ${source.official ? 'official' : ''}">
      <h3>${esc(source.name)}</h3>
      <p>${esc(source.description)}</p>
      <div class="conditions" style="margin-top:12px">
        <span class="badge ${source.official ? 'official' : 'source'}">${esc(source.kind)}</span>
        <a class="badge" href="${safeUrl(source.homepage)}" target="_blank" rel="noopener">来源主页 ↗</a>
      </div>
      <div class="source-status">
        <label class="switch"><input type="checkbox" data-action="toggle-source" data-id="${escAttr(source.id)}" ${enabled.has(source.id) ? 'checked' : ''}> 用于采集</label>
        <span class="small muted">${source.lastSuccessAt ? `成功 ${formatDateTime(source.lastSuccessAt)}` : '尚未成功采集'}</span>
      </div>
      ${source.lastError ? `<div class="source-error">最近错误：${esc(source.lastError)}</div>` : ''}
    </article>`).join('');
    $('#viewRoot').innerHTML = `<div class="page-head"><div><h1>来源管理</h1><p>至少启用一个来源。采集只读取公开页面或公开接口，不会把列表缺席误判为关闭。</p></div><button class="primary" data-action="scrape">采集已启用来源</button></div><div class="source-grid">${cards}</div>`;
  }

  async function handleViewAction(event) {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    if (action === 'open-job' || action === 'open-change') {
      if (action === 'open-change' && !target.classList.contains('seen')) markChangesSeen([target.dataset.id]);
      openJob(target.dataset.key);
    } else if (action === 'toggle-watch') {
      await toggleWatch(target.dataset.key, target.dataset.watched === 'true');
    } else if (action === 'new-filter') {
      openFilterDialog(null);
    } else if (action === 'edit-filter') {
      openFilterDialog(state.filters.find(filter => filter.id === target.dataset.id));
    } else if (action === 'delete-filter') {
      await deleteFilter(target.dataset.id);
    } else if (action === 'use-filter') {
      await useFilter(target.dataset.id);
    } else if (action === 'scrape') {
      await scrapeSelected(null);
    } else if (action === 'go-sources') {
      await switchView('sources');
    } else if (action === 'reset-search') {
      resetSearch();
    } else if (action === 'mark-all-seen') {
      await markChangesSeen(state.changes.filter(change => !change.seen).map(change => change.id));
    }
  }

  async function handleViewChange(event) {
    const target = event.target.closest('[data-action="toggle-source"]');
    if (!target) return;
    const sourceId = target.dataset.id;
    const selected = new Set(state.user.selectedSources || []);
    if (target.checked) selected.add(sourceId); else selected.delete(sourceId);
    if (!selected.size) {
      target.checked = true;
      toast('至少保留一个岗位来源', true);
      return;
    }
    try {
      const result = await api('/api/preferences/sources', { method: 'POST', body: { sourceIds: [...selected] } });
      state.user = result.user;
      state.sources = result.sources || state.sources;
      renderChrome();
      renderView();
      toast('来源选择已保存');
    } catch (error) { toast(error.message, true); }
  }
  function openFilterDialog(filter) {
    const item = filter || { id: '', name: '', keyword: state.query, city: state.city };
    $('#modalRoot').hidden = false;
    $('#modalRoot').innerHTML = `<section class="modal" role="dialog" aria-modal="true">
      <header class="modal-header"><div><h2>${filter ? '修改筛选方案' : '保存筛选方案'}</h2><p>方案保存关键词与城市，不保存岗位结果。</p></div><button class="modal-close" data-close="1">×</button></header>
      <div class="modal-body">
        <form id="filterForm" class="dialog-form">
          <input type="hidden" id="dialogFilterId" value="${escAttr(item.id)}">
          <label>方案名称<input id="dialogFilterName" required maxlength="60" value="${escAttr(item.name)}" placeholder="例如：上海后端"></label>
          <label>关键词<input id="dialogFilterKeyword" value="${escAttr(item.keyword || '')}" placeholder="匹配岗位名称或岗位要求"></label>
          <label>城市<input id="dialogFilterCity" list="dialogCityList" value="${escAttr(item.city || '')}" placeholder="留空表示不限"><datalist id="dialogCityList">${state.cities.map(city => `<option value="${escAttr(city)}"></option>`).join('')}</datalist></label>
          <p class="muted small">城市按值精确匹配；关键词与城市同时填写时需要同时满足。</p>
          <div class="dialog-actions"><button type="button" class="ghost" data-close="1">取消</button><button type="submit" class="primary">保存方案</button></div>
        </form>
      </div>
    </section>`;
  }

  async function handleModalSubmit(event) {
    if (event.target.id !== 'filterForm') return;
    event.preventDefault();
    const id = $('#dialogFilterId').value;
    const body = {
      id: id || null,
      name: $('#dialogFilterName').value.trim(),
      keyword: $('#dialogFilterKeyword').value.trim(),
      city: $('#dialogFilterCity').value.trim()
    };
    try {
      const result = await api('/api/filters', { method: 'POST', body });
      state.filters = result.filters || state.filters;
      closeModal();
      toast(id ? '筛选方案已修改' : '筛选方案已保存');
      if (state.view === 'filters') renderView();
    } catch (error) { toast(error.message, true); }
  }

  async function handleModalAction(event) {
    if (event.target === $('#modalRoot')) { closeModal(); return; }
    const close = event.target.closest('[data-close]');
    if (close) { closeModal(); return; }
    const target = event.target.closest('[data-modal-action]');
    if (!target) return;
    if (target.dataset.modalAction === 'toggle-watch-detail') {
      const key = target.dataset.key;
      const watched = target.dataset.watched === 'true';
      await toggleWatch(key, watched);
      await openJob(key);
    }
  }

  async function openJob(jobKey) {
    $('#modalRoot').hidden = false;
    $('#modalRoot').innerHTML = '<section class="modal"><div class="modal-body">正在读取岗位详情…</div></section>';
    try {
      const result = await api(`/api/jobs/detail?jobKey=${encodeURIComponent(jobKey)}`);
      const job = result.job;
      const changes = job.changes || [];
      const changeHtml = changes.length ? `<section class="detail-section"><h3>关注期间的变化</h3><div class="change-list">${changes.map(change => `<div class="change-card"><div><span class="change-field">${esc(FIELD_LABELS[change.field] || change.field)}</span></div><div class="change-main"><div class="diff"><div class="diff-row"><b>原值</b><span>${esc(displayChangeValue(change.field, change.oldValue))}</span></div><div class="diff-row"><b>新值</b><span>${esc(displayChangeValue(change.field, change.newValue))}</span></div></div></div><div class="change-time">${esc(formatDateTime(change.changedAt))}</div></div>`).join('')}</div></section>` : '';
      $('#modalRoot').innerHTML = `<section class="modal" role="dialog" aria-modal="true">
        <header class="modal-header">
          <div><h2>${esc(job.title || '未命名岗位')}</h2><p>${esc(job.company || '公司未提供')} · ${esc(job.sourceName || '')}</p></div>
          <button class="modal-close" data-close="1">×</button>
        </header>
        <div class="modal-body">
          <div class="detail-grid">
            <div class="detail-item"><span>城市</span><b>${esc(displayValue(job.city))}</b></div>
            <div class="detail-item"><span>截止时间</span><b>${esc(displayValue(job.deadline))}</b></div>
            <div class="detail-item"><span>招聘状态</span><b>${esc(displayStatus(job.status))}</b></div>
            <div class="detail-item"><span>来源</span><b>${esc(job.sourceName || '')}</b></div>
            <div class="detail-item"><span>最近抓取</span><b>${esc(formatDateTime(job.lastFetchedAt))}</b></div>
            <div class="detail-item"><span>发布时间 / 更新提示</span><b>${esc(displayValue(job.postedAt || job.sourceUpdatedAt))}</b></div>
          </div>
          <section class="detail-section"><h3>岗位要求</h3><p class="detail-text">${esc(displayValue(job.requirements))}</p></section>
          ${job.description && job.description !== job.requirements ? `<section class="detail-section"><h3>岗位描述</h3><p class="detail-text">${esc(job.description)}</p></section>` : ''}
          ${changeHtml}
          <div class="detail-actions">
            <a class="secondary" style="text-decoration:none" href="${safeUrl(job.url)}" target="_blank" rel="noopener">打开原始链接 ↗</a>
            <button class="${job.watched ? 'danger-button' : 'primary'}" data-modal-action="toggle-watch-detail" data-key="${escAttr(job.jobKey)}" data-watched="${job.watched}">${job.watched ? '取消关注' : '关注岗位'}</button>
          </div>
        </div>
      </section>`;
    } catch (error) {
      $('#modalRoot').innerHTML = `<section class="modal"><div class="modal-body"><h2>无法读取岗位</h2><p class="muted">${esc(error.message)}</p><button class="secondary" data-close="1">关闭</button></div></section>`;
    }
  }

  async function toggleWatch(jobKey, watched) {
    try {
      await api(watched ? '/api/unwatch' : '/api/watch', { method: 'POST', body: { jobKey } });
      await refreshBootstrap();
      if (state.view === 'jobs' || state.view === 'watched') await loadViewData();
      renderChrome();
      renderView();
      toast(watched ? '已取消关注；历史动态仍保留' : '已关注，之后的岗位变化会进入关注动态');
    } catch (error) { toast(error.message, true); }
  }
  async function scrapeSelected(sourceIds) {
    if (state.loading) return;
    const selected = sourceIds || state.user.selectedSources || [];
    if (!selected.length) { toast('请先启用至少一个岗位来源', true); return; }
    state.loading = true;
    const buttons = document.querySelectorAll('[data-action="scrape"]');
    buttons.forEach(button => { button.disabled = true; button.classList.add('loading'); button.textContent = '采集中'; });
    $('#refreshBtn').disabled = true;
    try {
      const result = await api('/api/scrape', { method: 'POST', body: { sourceIds: selected } });
      reportScrape(result);
    } catch (error) {
      if (error.payload && error.payload.results) reportScrape(error.payload);
      else toast(error.message, true);
    } finally {
      state.loading = false;
      $('#refreshBtn').disabled = false;
      buttons.forEach(button => { button.disabled = false; button.classList.remove('loading'); button.textContent = '采集已启用来源'; });
      try {
        await refreshBootstrap();
        if (state.view === 'jobs' || state.view === 'watched') await loadViewData();
        renderChrome();
        renderView();
      } catch (_) {}
    }
  }

  function reportScrape(result) {
    const rows = result.results || [];
    const succeeded = rows.filter(row => row.success);
    const failed = rows.filter(row => !row.success);
    if (succeeded.length) {
      const created = succeeded.reduce((sum, row) => sum + (row.createdCount || 0), 0);
      const updated = succeeded.reduce((sum, row) => sum + (row.updatedCount || 0), 0);
      const changes = succeeded.reduce((sum, row) => sum + (row.changeCount || 0), 0);
      toast(`采集完成：新增 ${created}，更新 ${updated}，关注变化 ${changes}${failed.length ? `；${failed.length} 个来源失败` : ''}`);
    }
    if (failed.length) toast(`${failed.map(row => row.sourceId + ': ' + row.error).join('；')}`, true);
  }

  async function deleteFilter(id) {
    if (!window.confirm('确认删除这个筛选方案？')) return;
    try {
      const result = await api(`/api/filters?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
      state.filters = result.filters || [];
      renderView();
      toast('筛选方案已删除');
    } catch (error) { toast(error.message, true); }
  }

  async function useFilter(id) {
    const filter = state.filters.find(item => item.id === id);
    if (!filter) return;
    state.query = filter.keyword || '';
    state.city = filter.city || '';
    state.source = '';
    state.view = 'jobs';
    try {
      await loadViewData();
      renderChrome();
      renderView();
      toast(`已应用方案：${filter.name}`);
    } catch (error) { toast(error.message, true); }
  }

  async function markChangesSeen(ids) {
    if (!ids || !ids.length) return;
    try {
      await api('/api/changes/seen', { method: 'POST', body: { ids } });
      await refreshBootstrap();
      if (state.view === 'changes') await loadViewData();
      renderChrome();
      if (state.view === 'changes') renderView();
    } catch (error) { toast(error.message, true); }
  }

  function closeModal() {
    $('#modalRoot').hidden = true;
    $('#modalRoot').innerHTML = '';
  }

  let toastTimer = null;
  function toast(message, isError = false) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.toggle('error', isError);
    node.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { node.hidden = true; }, 4200);
  }

  function displayValue(value) {
    if (value === null || value === undefined || String(value).trim() === '') return '未提供';
    return String(value);
  }

  function displayStatus(value) {
    if (value === null || value === undefined || String(value).trim() === '') return '未提供';
    return STATUS_LABELS[String(value).toLowerCase()] || String(value);
  }

  function displayChangeValue(field, value) {
    if (value === null || value === undefined || String(value).trim() === '') return '未提供';
    if (field === 'status') return displayStatus(value);
    const text = String(value);
    return text.length > 180 ? text.slice(0, 180) + '…' : text;
  }

  function excerpt(value) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    return text.length > 360 ? text.slice(0, 360) + '…' : text;
  }

  function formatDateTime(value) {
    if (!value) return '未提供';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return new Intl.DateTimeFormat('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
  }

  function safeUrl(value) {
    try {
      const url = new URL(String(value || ''), window.location.origin);
      return ['http:', 'https:'].includes(url.protocol) ? url.href : '#';
    } catch (_) { return '#'; }
  }

  function esc(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function escAttr(value) { return esc(value); }

  async function init() {
    bindEvents();
    $('#viewRoot').addEventListener('change', handleViewChange);
    if (!state.token) return;
    try {
      await enterApp();
    } catch (error) {
      signOut(false);
      $('#authError').textContent = error.message || '登录已失效，请重新登录';
    }
  }

  init();
})();
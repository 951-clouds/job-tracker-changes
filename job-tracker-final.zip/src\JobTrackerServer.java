import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;

/** Local HTTP server for the job tracker. */
public final class JobTrackerServer {
    private final Store store;
    private final Path staticDir;

    private JobTrackerServer(Store store, Path staticDir) {
        this.store = store;
        this.staticDir = staticDir.toAbsolutePath().normalize();
    }

    public static void main(String[] args) throws Exception {
        int port = 8787;
        Path dataFile = Path.of("data", "jobtracker-state.json");
        Path staticDir = Path.of("static");
        for (int i = 0; i < args.length; i++) {
            if ("--port".equals(args[i]) && i + 1 < args.length) port = Integer.parseInt(args[++i]);
            else if ("--data".equals(args[i]) && i + 1 < args.length) dataFile = Path.of(args[++i]);
            else if ("--static".equals(args[i]) && i + 1 < args.length) staticDir = Path.of(args[++i]);
        }
        Store store = new Store(dataFile);
        JobTrackerServer app = new JobTrackerServer(store, staticDir);
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.createContext("/", app::handle);
        server.setExecutor(Executors.newFixedThreadPool(Math.max(4, Runtime.getRuntime().availableProcessors())));
        server.start();
        System.out.println("Job Tracker running at http://127.0.0.1:" + port);
        System.out.println("Static: " + staticDir.toAbsolutePath().normalize());
        System.out.println("Data:   " + dataFile.toAbsolutePath().normalize());
    }

    private void handle(HttpExchange exchange) throws IOException {
        try {
            String path = exchange.getRequestURI().getPath();
            if (path.startsWith("/api/")) routeApi(exchange, path);
            else serveStatic(exchange, path);
        } catch (IllegalArgumentException ex) {
            sendError(exchange, 400, ex.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
            sendError(exchange, 500, "服务器处理失败: " + ex.getMessage());
        } finally {
            exchange.close();
        }
    }

    private void routeApi(HttpExchange exchange, String path) throws Exception {
        String method = exchange.getRequestMethod().toUpperCase(Locale.ROOT);
        if ("GET".equals(method) && "/api/health".equals(path)) {
            sendJson(exchange, 200, Json.obj().set("ok", true).set("time", Instant.now().toString()));
            return;
        }
        if ("POST".equals(method) && "/api/auth/register".equals(path)) {
            Json.Obj body = body(exchange);
            Json.Obj user = store.register(Json.text(body, "username"), Json.text(body, "password"), Json.text(body, "displayName"));
            Json.Obj loggedIn = store.login(Json.text(user, "username"), Json.text(body, "password"));
            sendJson(exchange, 201, Json.obj().set("user", loggedIn).set("sources", store.listSources()));
            return;
        }
        if ("POST".equals(method) && "/api/auth/login".equals(path)) {
            Json.Obj body = body(exchange);
            Json.Obj user = store.login(Json.text(body, "username"), Json.text(body, "password"));
            sendJson(exchange, 200, Json.obj().set("user", user).set("sources", store.listSources()));
            return;
        }
        if ("POST".equals(method) && "/api/auth/logout".equals(path)) {
            store.logout(token(exchange));
            sendJson(exchange, 200, Json.obj().set("ok", true));
            return;
        }
        Json.Obj user = store.authenticate(token(exchange));
        if (user == null) {
            sendError(exchange, 401, "请先登录");
            return;
        }
        String userId = Json.text(user, "id");

        if ("GET".equals(method) && "/api/bootstrap".equals(path)) {
            sendJson(exchange, 200, store.bootstrap(userId));
            return;
        }
        if ("GET".equals(method) && "/api/jobs".equals(path)) {
            Map<String, String> query = query(exchange);
            boolean watchedOnly = "1".equals(query.get("watched")) || "true".equalsIgnoreCase(query.get("watched"));
            sendJson(exchange, 200, Json.obj()
                    .set("jobs", store.queryJobs(userId, query.get("q"), query.get("city"), query.get("source"), watchedOnly))
                    .set("cities", store.cities()));
            return;
        }
        if ("GET".equals(method) && "/api/jobs/detail".equals(path)) {
            sendJson(exchange, 200, Json.obj().set("job", store.jobDetail(userId, query(exchange).get("jobKey"))));
            return;
        }
        if ("GET".equals(method) && "/api/filters".equals(path)) {
            sendJson(exchange, 200, Json.obj().set("filters", store.filters(userId)));
            return;
        }
        if ("POST".equals(method) && "/api/filters".equals(path)) {
            Json.Obj body = body(exchange);
            Json.Obj saved = store.saveFilter(userId, Json.text(body, "id"), Json.text(body, "name"), Json.text(body, "keyword"), Json.text(body, "city"));
            sendJson(exchange, 200, Json.obj().set("filter", saved).set("filters", store.filters(userId)));
            return;
        }
        if ("DELETE".equals(method) && "/api/filters".equals(path)) {
            store.deleteFilter(userId, query(exchange).get("id"));
            sendJson(exchange, 200, Json.obj().set("ok", true).set("filters", store.filters(userId)));
            return;
        }        if ("POST".equals(method) && "/api/watch".equals(path)) {
            Json.Obj body = body(exchange);
            sendJson(exchange, 200, Json.obj().set("watch", store.watch(userId, Json.text(body, "jobKey"))));
            return;
        }
        if ("POST".equals(method) && "/api/unwatch".equals(path)) {
            Json.Obj body = body(exchange);
            store.unwatch(userId, Json.text(body, "jobKey"));
            sendJson(exchange, 200, Json.obj().set("ok", true));
            return;
        }
        if ("GET".equals(method) && "/api/changes".equals(path)) {
            Map<String, String> query = query(exchange);
            sendJson(exchange, 200, Json.obj().set("changes", store.changes(userId, query.get("jobKey"), "1".equals(query.get("unread")))));
            return;
        }
        if ("POST".equals(method) && "/api/changes/seen".equals(path)) {
            Json.Obj body = body(exchange);
            store.markChangesSeen(userId, strings(body.get("ids")));
            sendJson(exchange, 200, Json.obj().set("ok", true).set("unreadChanges", store.bootstrap(userId).get("unreadChanges")));
            return;
        }
        if ("POST".equals(method) && "/api/preferences/sources".equals(path)) {
            Json.Obj body = body(exchange);
            Json.Obj updated = store.updateSelectedSources(userId, strings(body.get("sourceIds")));
            sendJson(exchange, 200, Json.obj().set("user", updated).set("sources", store.listSources()));
            return;
        }
        if ("POST".equals(method) && ("/api/scrape".equals(path) || "/api/refresh".equals(path))) {
            scrape(exchange, user, body(exchange));
            return;
        }
        sendError(exchange, 404, "接口不存在");
    }

    private void scrape(HttpExchange exchange, Json.Obj user, Json.Obj request) throws Exception {
        List<String> requested = strings(request.get("sourceIds"));
        if (requested.isEmpty()) requested = strings(user.get("selectedSources"));
        List<String> allowed = strings(user.get("selectedSources"));
        Json.Arr results = Json.arr();
        int successCount = 0;
        for (String sourceId : requested) {
            if (!allowed.contains(sourceId)) {
                results.add(Json.obj().set("sourceId", sourceId).set("success", false).set("error", "未在当前账号启用该来源"));
                continue;
            }
            long started = System.currentTimeMillis();
            try {
                List<Map<String, Object>> jobs = Scrapers.fetch(sourceId);
                Json.Obj result = store.applyScrapedJobs(sourceId, jobs, System.currentTimeMillis() - started);
                results.add(result);
                successCount++;
            } catch (Exception ex) {
                Json.Obj failed = store.recordSourceError(sourceId, friendlyError(ex), System.currentTimeMillis() - started);
                results.add(failed);
            }
        }
        Map<String, String> query = query(exchange);
        Json.Obj response = Json.obj()
                .set("results", results)
                .set("successCount", successCount)
                .set("totalJobs", store.bootstrap(Json.text(user, "id")).get("totalJobs"))
                .set("lastSuccessfulScrapeAt", store.bootstrap(Json.text(user, "id")).get("lastSuccessfulScrapeAt"));
        sendJson(exchange, 200, response);
    }
    private void serveStatic(HttpExchange exchange, String requestPath) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendError(exchange, 405, "仅支持 GET");
            return;
        }
        String relative = requestPath == null || requestPath.equals("/") ? "index.html" : requestPath.substring(1);
        relative = URLDecoder.decode(relative, StandardCharsets.UTF_8);
        Path target = staticDir.resolve(relative).normalize();
        if (!target.startsWith(staticDir)) {
            sendError(exchange, 403, "禁止访问");
            return;
        }
        if (!Files.exists(target) || Files.isDirectory(target)) {
            sendError(exchange, 404, "页面不存在");
            return;
        }
        byte[] body = Files.readAllBytes(target);
        String contentType = contentType(target.getFileName().toString());
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(200, body.length);
        try (OutputStream out = exchange.getResponseBody()) { out.write(body); }
    }

    private Json.Obj body(HttpExchange exchange) throws IOException {
        byte[] bytes = exchange.getRequestBody().readAllBytes();
        if (bytes.length == 0) return Json.obj();
        if (bytes.length > 2_000_000) throw new IllegalArgumentException("请求内容过大");
        String text = new String(bytes, StandardCharsets.UTF_8);
        return Json.asObj(Json.parse(text));
    }

    private Map<String, String> query(HttpExchange exchange) {
        Map<String, String> result = new LinkedHashMap<>();
        String raw = exchange.getRequestURI().getRawQuery();
        if (raw == null || raw.isBlank()) return result;
        for (String pair : raw.split("&")) {
            if (pair.isEmpty()) continue;
            int split = pair.indexOf('=');
            String key = split < 0 ? pair : pair.substring(0, split);
            String value = split < 0 ? "" : pair.substring(split + 1);
            result.put(URLDecoder.decode(key, StandardCharsets.UTF_8), URLDecoder.decode(value, StandardCharsets.UTF_8));
        }
        return result;
    }

    private static List<String> strings(Object value) {
        List<String> result = new ArrayList<>();
        if (value instanceof List<?>) {
            for (Object item : (List<?>) value) if (item != null && !String.valueOf(item).isBlank()) result.add(String.valueOf(item));
        } else if (value instanceof String && !((String) value).isBlank()) {
            result.add((String) value);
        }
        return result;
    }

    private String token(HttpExchange exchange) {
        String authorization = exchange.getRequestHeaders().getFirst("Authorization");
        if (authorization != null && authorization.regionMatches(true, 0, "Bearer ", 0, 7)) return authorization.substring(7).trim();
        String cookie = exchange.getRequestHeaders().getFirst("Cookie");
        if (cookie != null) {
            for (String item : cookie.split(";")) {
                String[] pair = item.trim().split("=", 2);
                if (pair.length == 2 && "jobtracker_token".equals(pair[0])) return pair[1];
            }
        }
        return null;
    }

    private void sendJson(HttpExchange exchange, int status, Object value) throws IOException {
        byte[] bytes = Json.stringify(value).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) { out.write(bytes); }
    }

    private void sendError(HttpExchange exchange, int status, String message) throws IOException {
        if (exchange.getResponseCode() != -1) return;
        sendJson(exchange, status, Json.obj().set("error", message == null ? "请求失败" : message));
    }

    private static String contentType(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html; charset=utf-8";
        if (lower.endsWith(".css")) return "text/css; charset=utf-8";
        if (lower.endsWith(".js")) return "text/javascript; charset=utf-8";
        if (lower.endsWith(".json")) return "application/json; charset=utf-8";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    private static String friendlyError(Exception ex) {
        String message = ex.getMessage();
        if (message == null || message.isBlank()) message = ex.getClass().getSimpleName();
        return message.length() > 400 ? message.substring(0, 400) + "..." : message;
    }
}
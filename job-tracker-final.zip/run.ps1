﻿param(
  [int]$Port = 8787,
  [string]$DataFile = "data\jobtracker-state.json"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$java = Get-Command java -ErrorAction SilentlyContinue
$javac = Get-Command javac -ErrorAction SilentlyContinue
if (-not $java -or -not $javac) {
  throw "未找到 Java/JDK。请安装 Java 17 或更高版本，并确保 java、javac 位于 PATH。"
}

$buildDir = Join-Path $root "build\classes"
New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
$sources = Get-ChildItem -LiteralPath (Join-Path $root "src") -Filter "*.java" | ForEach-Object { $_.FullName }
& javac -encoding UTF-8 -d $buildDir $sources
if ($LASTEXITCODE -ne 0) { throw "Java 编译失败。" }

$dataPath = if ([IO.Path]::IsPathRooted($DataFile)) { $DataFile } else { Join-Path $root $DataFile }
$staticPath = Join-Path $root "static"
Write-Host ""
Write-Host "岗位雷达已启动： http://127.0.0.1:$Port" -ForegroundColor Green
Write-Host "首次使用请创建账号，然后在“来源管理”中确认来源并执行采集。"
Write-Host "按 Ctrl+C 停止服务。"
Write-Host ""

& java -cp $buildDir JobTrackerServer --port $Port --data $dataPath --static $staticPath
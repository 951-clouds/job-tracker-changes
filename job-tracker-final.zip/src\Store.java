import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

/** JSON-backed application store. All user-owned collections are keyed by user id. */
final class Store {
    private static final Pattern USERNAME = Pattern.compile("[a-zA-Z0-9_.-]{3,32}");
    private static final int PBKDF2_ITERATIONS = 120_000;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final List<String> CHANGE_FIELDS = List.of("requirements", "deadline", "status");

    private final Path file;
    private final Json.Obj root;

    Store(Path file) throws IOException {
        this.file = file.toAbsolutePath().normalize();
        this.root = load();
    }

    private Json.Obj load() throws IOException {
        Json.Obj loaded = null;
        if (Files.exists(file)) {
            String text = Files.readString(file, StandardCharsets.UTF_8);
            if (!text.isBlank()) loaded = Json.asObj(Json.parse(text));
        }
        if (loaded == null) {
            loaded = Json.obj()
                    .set("version", 1)
                    .set("sources", defaultSources())
                    .set("jobs", Json.obj())
                    .set("users", Json.obj())
                    .set("sessions", Json.obj())
                    .set("filters", Json.obj())
                    .set("watches", Json.obj())
                    .set("changes", Json.obj())
                    .set("runs", Json.arr());
            try { saveTo(file, loaded); } catch (IOException ex) { throw new IOException("无法写入数据文件", ex); }
        }
        ensureRoot(loaded);
        return loaded;
    }

    private void ensureRoot(Json.Obj data) {
        data.putIfAbsent("version", 1);
        Json.Obj sources = map(data, "sources");
        Json.Obj defaults = defaultSources();
        for (Map.Entry<String, Object> entry : defaults.entrySet()) {
            Json.Obj existing = sources.get(entry.getKey()) instanceof Map<?, ?> ? Json.asObj(sources.get(entry.getKey())) : Json.obj();
            Json.Obj template = Json.asObj(entry.getValue());
            for (Map.Entry<String, Object> field : template.entrySet()) existing.putIfAbsent(field.getKey(), field.getValue());
            sources.put(entry.getKey(), existing);
        }
        data.putIfAbsent("jobs", Json.obj());
        data.putIfAbsent("users", Json.obj());
        data.putIfAbsent("sessions", Json.obj());
        data.putIfAbsent("filters", Json.obj());
        data.putIfAbsent("watches", Json.obj());
        data.putIfAbsent("changes", Json.obj());
        data.putIfAbsent("runs", Json.arr());
    }

    private static Json.Obj defaultSources() {
        return Json.obj()
                .set("remotive", Json.obj()
                        .set("id", "remotive").set("name", "Remotive").set("kind", "招聘平台")
                        .set("official", false).set("homepage", "https://remotive.com/")
                        .set("description", "通过 Remotive 公开 API 获取远程岗位")
                        .set("lastSuccessAt", null).set("lastError", null)
                        .set("lastFetchedCount", 0).set("lastDurationMs", null))
                .set("amazon", Json.obj()
                        .set("id", "amazon").set("name", "Amazon Jobs").set("kind", "大厂官方")
                        .set("official", true).set("homepage", "https://www.amazon.jobs/")
                        .set("description", "通过 Amazon Jobs 官方搜索接口获取岗位")
                        .set("lastSuccessAt", null).set("lastError", null)
                        .set("lastFetchedCount", 0).set("lastDurationMs", null));
    }
    synchronized Json.Obj register(String username, String password, String displayName) {
        String normalized = normalizeUsername(username);
        if (!USERNAME.matcher(normalized).matches()) throw new IllegalArgumentException("账号需为 3-32 位字母、数字、点、下划线或短横线");
        if (password == null || password.length() < 6) throw new IllegalArgumentException("密码至少 6 位");
        Json.Obj users = map(root, "users");
        for (Object value : users.values()) {
            Json.Obj user = Json.asObj(value);
            if (normalized.equalsIgnoreCase(Json.text(user, "username"))) throw new IllegalArgumentException("该账号已存在");
        }
        String salt = randomToken(18);
        String userId = UUID.randomUUID().toString();
        Json.Obj user = Json.obj()
                .set("id", userId)
                .set("username", normalized)
                .set("displayName", displayName == null || displayName.isBlank() ? normalized : displayName.trim())
                .set("salt", salt)
                .set("passwordHash", hashPassword(password, salt))
                .set("createdAt", Instant.now().toString())
                .set("selectedSources", new Json.Arr().addAllItems(defaultSourceIds()));
        users.put(userId, user);
        save();
        return user;
    }

    synchronized Json.Obj login(String username, String password) {
        String normalized;
        try { normalized = normalizeUsername(username); }
        catch (IllegalArgumentException ex) { throw new IllegalArgumentException("账号或密码错误"); }
        Json.Obj found = null;
        for (Object value : map(root, "users").values()) {
            Json.Obj user = Json.asObj(value);
            if (normalized.equalsIgnoreCase(Json.text(user, "username"))) { found = user; break; }
        }
        if (found == null || !verifyPassword(password, Json.text(found, "salt"), Json.text(found, "passwordHash"))) {
            throw new IllegalArgumentException("账号或密码错误");
        }
        String token = createSession(Json.text(found, "id"));
        save();
        Json.Obj response = publicUser(found);
        response.set("token", token);
        return response;
    }

    synchronized void logout(String token) {
        if (token != null) map(root, "sessions").remove(token);
        save();
    }

    synchronized Json.Obj authenticate(String token) {
        if (token == null || token.isBlank()) return null;
        Json.Obj sessions = map(root, "sessions");
        Object sessionValue = sessions.get(token);
        if (!(sessionValue instanceof Map<?, ?>)) return null;
        Json.Obj session = Json.asObj(sessionValue);
        String expiresAt = Json.text(session, "expiresAt");
        if (expiresAt == null || Instant.parse(expiresAt).isBefore(Instant.now())) {
            sessions.remove(token);
            save();
            return null;
        }
        Object userValue = map(root, "users").get(Json.text(session, "userId"));
        return userValue instanceof Map<?, ?> ? Json.asObj(userValue) : null;
    }

    private String createSession(String userId) {
        purgeExpiredSessions();
        String token = randomToken(32);
        map(root, "sessions").put(token, Json.obj()
                .set("userId", userId)
                .set("createdAt", Instant.now().toString())
                .set("expiresAt", Instant.now().plus(14, ChronoUnit.DAYS).toString()));
        return token;
    }

    private void purgeExpiredSessions() {
        Json.Obj sessions = map(root, "sessions");
        Instant now = Instant.now();
        List<String> expired = new ArrayList<>();
        for (Map.Entry<String, Object> entry : sessions.entrySet()) {
            try {
                if (Instant.parse(Json.text(Json.asObj(entry.getValue()), "expiresAt")).isBefore(now)) expired.add(entry.getKey());
            } catch (Exception ex) { expired.add(entry.getKey()); }
        }
        for (String key : expired) sessions.remove(key);
    }

    private static String normalizeUsername(String username) {
        if (username == null) throw new IllegalArgumentException("请输入账号");
        return username.trim().toLowerCase(Locale.ROOT);
    }

    private static String hashPassword(String password, String salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), Base64.getUrlDecoder().decode(salt), PBKDF2_ITERATIONS, 256);
            byte[] bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(bytes);
        } catch (Exception ex) {
            throw new IllegalStateException("密码处理失败", ex);
        }
    }

    private static boolean verifyPassword(String password, String salt, String expected) {
        if (password == null || expected == null || salt == null) return false;
        return MessageDigest.isEqual(hashPassword(password, salt).getBytes(StandardCharsets.US_ASCII), expected.getBytes(StandardCharsets.US_ASCII));
    }

    private static String randomToken(int byteCount) {
        byte[] bytes = new byte[byteCount];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
    synchronized Json.Obj publicUser(Json.Obj user) {
        return Json.obj()
                .set("id", Json.text(user, "id"))
                .set("username", Json.text(user, "username"))
                .set("displayName", Json.text(user, "displayName"))
                .set("selectedSources", new Json.Arr().addAllItems(stringList(user.get("selectedSources"))));
    }

    synchronized Json.Arr listSources() {
        Json.Arr result = Json.arr();
        for (String sourceId : defaultSourceIds()) {
            Object source = map(root, "sources").get(sourceId);
            if (source instanceof Map<?, ?>) result.add(Json.asObj(source).copy());
        }
        return result;
    }

    synchronized Json.Obj updateSelectedSources(String userId, List<String> sourceIds) {
        Json.Obj user = requireUser(userId);
        List<String> valid = new ArrayList<>();
        for (String sourceId : sourceIds == null ? List.<String>of() : sourceIds) {
            if (defaultSourceIds().contains(sourceId) && !valid.contains(sourceId)) valid.add(sourceId);
        }
        if (valid.isEmpty()) throw new IllegalArgumentException("至少保留一个岗位来源");
        user.put("selectedSources", new Json.Arr().addAllItems(valid));
        save();
        return publicUser(user);
    }

    synchronized Json.Obj bootstrap(String userId) {
        Json.Obj user = requireUser(userId);
        int watched = 0;
        for (Object value : watchesFor(userId)) if (Json.bool(Json.asObj(value), "active", false)) watched++;
        int unread = 0;
        for (Object value : changesFor(userId)) if (!Json.bool(Json.asObj(value), "seen", false)) unread++;
        return Json.obj()
                .set("user", publicUser(user))
                .set("sources", listSources())
                .set("cities", cities())
                .set("totalJobs", map(root, "jobs").size())
                .set("watchedCount", watched)
                .set("unreadChanges", unread)
                .set("lastSuccessfulScrapeAt", lastSuccessfulScrapeAt());
    }

    synchronized Json.Arr queryJobs(String userId, String keyword, String city, String sourceId, boolean watchedOnly) {
        requireUser(userId);
        String q = keyword == null ? "" : keyword.trim().toLowerCase(Locale.ROOT);
        String selectedCity = city == null ? "" : city.trim();
        String selectedSource = sourceId == null ? "" : sourceId.trim();
        List<Json.Obj> rows = new ArrayList<>();
        for (Object value : map(root, "jobs").values()) {
            Json.Obj job = Json.asObj(value);
            if (!selectedSource.isEmpty() && !selectedSource.equals(Json.text(job, "sourceId"))) continue;
            if (!selectedCity.isEmpty() && !selectedCity.equalsIgnoreCase(Json.text(job, "city"))) continue;
            if (!q.isEmpty()) {
                String title = safeLower(Json.text(job, "title"));
                String requirements = safeLower(Json.text(job, "requirements"));
                if (!title.contains(q) && !requirements.contains(q)) continue;
            }
            Json.Obj watch = activeWatch(userId, Json.text(job, "jobKey"));
            if (watchedOnly && watch == null) continue;
            Json.Obj row = job.copy();
            row.set("watched", watch != null);
            row.set("watchCreatedAt", watch == null ? null : Json.text(watch, "createdAt"));
            rows.add(row);
        }
        rows.sort(Comparator.comparing((Json.Obj row) -> nullSafe(Json.text(row, "lastSeenAt"))).reversed());
        return new Json.Arr().addAllItems(rows);
    }

    synchronized Json.Obj jobDetail(String userId, String jobKey) {
        requireUser(userId);
        Json.Obj job = findJob(jobKey);
        if (job == null) throw new IllegalArgumentException("岗位不存在或尚未采集");
        Json.Obj result = job.copy();
        Json.Obj watch = activeWatch(userId, jobKey);
        result.set("watched", watch != null);
        result.set("watchCreatedAt", watch == null ? null : Json.text(watch, "createdAt"));
        result.set("changes", changesForJob(userId, jobKey));
        return result;
    }

    synchronized Json.Arr cities() {
        Map<String, Boolean> seen = new LinkedHashMap<>();
        for (Object value : map(root, "jobs").values()) {
            String city = Json.text(Json.asObj(value), "city");
            if (city != null && !city.isBlank()) seen.put(city, Boolean.TRUE);
        }
        List<String> cities = new ArrayList<>(seen.keySet());
        cities.sort(String.CASE_INSENSITIVE_ORDER);
        return new Json.Arr().addAllItems(cities);
    }
    synchronized Json.Arr filters(String userId) {
        requireUser(userId);
        Json.Arr list = userList(root, "filters", userId);
        list.sort(Comparator.comparing((Object value) -> nullSafe(Json.text(Json.asObj(value), "updatedAt"))).reversed());
        return list.copy();
    }

    synchronized Json.Obj saveFilter(String userId, String id, String name, String keyword, String city) {
        requireUser(userId);
        if (name == null || name.isBlank()) throw new IllegalArgumentException("方案名称不能为空");
        if (name.trim().length() > 60) throw new IllegalArgumentException("方案名称不能超过 60 字");
        keyword = keyword == null ? "" : keyword.trim();
        city = city == null ? "" : city.trim();
        Json.Arr list = userList(root, "filters", userId);
        Json.Obj saved = null;
        if (id != null && !id.isBlank()) {
            for (Object value : list) {
                Json.Obj item = Json.asObj(value);
                if (id.equals(Json.text(item, "id"))) { saved = item; break; }
            }
            if (saved == null) throw new IllegalArgumentException("筛选方案不存在");
        }
        String now = Instant.now().toString();
        if (saved == null) {
            saved = Json.obj()
                    .set("id", UUID.randomUUID().toString())
                    .set("userId", userId)
                    .set("createdAt", now);
            list.add(saved);
        }
        saved.set("name", name.trim()).set("keyword", keyword).set("city", city).set("updatedAt", now);
        save();
        return saved.copy();
    }

    synchronized void deleteFilter(String userId, String id) {
        requireUser(userId);
        Json.Arr list = userList(root, "filters", userId);
        boolean removed = list.removeIf(value -> id != null && id.equals(Json.text(Json.asObj(value), "id")));
        if (!removed) throw new IllegalArgumentException("筛选方案不存在");
        save();
    }
    synchronized Json.Obj watch(String userId, String jobKey) {
        requireUser(userId);
        if (findJob(jobKey) == null) throw new IllegalArgumentException("岗位不存在或尚未采集");
        Json.Arr list = userList(root, "watches", userId);
        Json.Obj existing = activeWatch(userId, jobKey);
        if (existing != null) return existing.copy();
        Json.Obj watch = Json.obj()
                .set("id", UUID.randomUUID().toString())
                .set("userId", userId)
                .set("jobKey", jobKey)
                .set("active", true)
                .set("createdAt", Instant.now().toString())
                .set("endedAt", null);
        list.add(watch);
        save();
        return watch.copy();
    }

    synchronized void unwatch(String userId, String jobKey) {
        requireUser(userId);
        Json.Obj watch = activeWatch(userId, jobKey);
        if (watch == null) return;
        watch.set("active", false).set("endedAt", Instant.now().toString());
        save();
    }

    synchronized Json.Arr changes(String userId, String jobKey, boolean unreadOnly) {
        requireUser(userId);
        List<Json.Obj> rows = new ArrayList<>();
        for (Object value : changesFor(userId)) {
            Json.Obj change = Json.asObj(value);
            if (jobKey != null && !jobKey.isBlank() && !jobKey.equals(Json.text(change, "jobKey"))) continue;
            if (unreadOnly && Json.bool(change, "seen", false)) continue;
            Json.Obj row = change.copy();
            Json.Obj job = findJob(Json.text(change, "jobKey"));
            if (job != null) row.set("job", summaryJob(job));
            rows.add(row);
        }
        rows.sort(Comparator.comparing((Json.Obj row) -> nullSafe(Json.text(row, "changedAt"))).reversed());
        return new Json.Arr().addAllItems(rows);
    }

    synchronized void markChangesSeen(String userId, List<String> changeIds) {
        requireUser(userId);
        boolean changed = false;
        for (Object value : changesFor(userId)) {
            Json.Obj change = Json.asObj(value);
            if (changeIds == null || changeIds.isEmpty() || changeIds.contains(Json.text(change, "id"))) {
                if (!Json.bool(change, "seen", false)) { change.set("seen", true); changed = true; }
            }
        }
        if (changed) save();
    }
    synchronized Json.Obj applyScrapedJobs(String sourceId, List<Map<String, Object>> scraped, long durationMs) {
        if (!defaultSourceIds().contains(sourceId)) throw new IllegalArgumentException("未知岗位来源");
        Json.Obj source = Json.asObj(map(root, "sources").get(sourceId));
        String now = Instant.now().toString();
        int created = 0;
        int updated = 0;
        int changed = 0;
        for (Map<String, Object> raw : scraped) {
            Json.Obj incoming = new Json.Obj().setAll(raw);
            String stableId = Json.text(incoming, "stableId");
            if (stableId == null || stableId.isBlank()) throw new IllegalArgumentException("来源 " + sourceId + " 的岗位缺少稳定 ID");
            String jobKey = sourceId + "|" + stableId;
            incoming.set("jobKey", jobKey).set("sourceId", sourceId).set("stableId", stableId);
            Json.Obj existing = findJob(jobKey);
            if (existing == null) {
                Json.Obj job = incoming.copy();
                job.set("sourceName", Json.text(source, "name"))
                        .set("firstSeenAt", now)
                        .set("lastSeenAt", now)
                        .set("lastFetchedAt", now);
                map(root, "jobs").put(jobKey, job);
                created++;
                continue;
            }
            for (String field : CHANGE_FIELDS) {
                Object oldValue = existing.get(field);
                Object newValue = incoming.get(field);
                if (!Objects.equals(oldValue, newValue)) {
                    int perWatcher = addChangesForWatchers(jobKey, field, oldValue, newValue, now);
                    if (perWatcher > 0) changed += perWatcher;
                }
            }
            for (Map.Entry<String, Object> entry : incoming.entrySet()) {
                if (!"jobKey".equals(entry.getKey()) && !"sourceId".equals(entry.getKey()) && !"stableId".equals(entry.getKey())) {
                    existing.put(entry.getKey(), Json.deepCopy(entry.getValue()));
                }
            }
            existing.set("sourceName", Json.text(source, "name"))
                    .set("lastSeenAt", now)
                    .set("lastFetchedAt", now);
            updated++;
        }
        source.set("lastSuccessAt", now)
                .set("lastError", null)
                .set("lastFetchedCount", scraped.size())
                .set("lastDurationMs", durationMs);
        Json.Arr runs = Json.asArr(root.get("runs"));
        runs.add(Json.obj()
                .set("id", UUID.randomUUID().toString())
                .set("sourceId", sourceId)
                .set("startedAt", now)
                .set("finishedAt", now)
                .set("success", true)
                .set("fetchedCount", scraped.size())
                .set("createdCount", created)
                .set("updatedCount", updated)
                .set("changeCount", changed)
                .set("durationMs", durationMs)
                .set("error", null));
        trimRuns(runs);
        save();
        return Json.obj()
                .set("sourceId", sourceId)
                .set("success", true)
                .set("fetchedCount", scraped.size())
                .set("createdCount", created)
                .set("updatedCount", updated)
                .set("changeCount", changed)
                .set("durationMs", durationMs);
    }

    synchronized Json.Obj recordSourceError(String sourceId, String message, long durationMs) {
        Json.Obj source = Json.asObj(map(root, "sources").get(sourceId));
        String now = Instant.now().toString();
        source.set("lastError", message == null ? "采集失败" : message);
        Json.Arr runs = Json.asArr(root.get("runs"));
        runs.add(Json.obj()
                .set("id", UUID.randomUUID().toString())
                .set("sourceId", sourceId)
                .set("startedAt", now)
                .set("finishedAt", now)
                .set("success", false)
                .set("fetchedCount", 0)
                .set("createdCount", 0)
                .set("updatedCount", 0)
                .set("changeCount", 0)
                .set("durationMs", durationMs)
                .set("error", message));
        trimRuns(runs);
        save();
        return Json.obj().set("sourceId", sourceId).set("success", false).set("error", message).set("durationMs", durationMs);
    }

    private int addChangesForWatchers(String jobKey, String field, Object oldValue, Object newValue, String changedAt) {
        int count = 0;
        Json.Obj watches = map(root, "watches");
        for (Map.Entry<String, Object> userEntry : watches.entrySet()) {
            String userId = userEntry.getKey();
            if (!(userEntry.getValue() instanceof List<?>)) continue;
            for (Object value : (List<?>) userEntry.getValue()) {
                Json.Obj watch = Json.asObj(value);
                if (Json.bool(watch, "active", false) && jobKey.equals(Json.text(watch, "jobKey"))) {
                    changesFor(userId).add(Json.obj()
                            .set("id", UUID.randomUUID().toString())
                            .set("userId", userId)
                            .set("jobKey", jobKey)
                            .set("field", field)
                            .set("oldValue", Json.deepCopy(oldValue))
                            .set("newValue", Json.deepCopy(newValue))
                            .set("changedAt", changedAt)
                            .set("seen", false));
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    private void trimRuns(Json.Arr runs) {
        while (runs.size() > 200) runs.remove(0);
    }

    synchronized String lastSuccessfulScrapeAt() {
        String latest = null;
        for (Object value : Json.asArr(root.get("runs"))) {
            Json.Obj run = Json.asObj(value);
            if (Json.bool(run, "success", false)) {
                String finishedAt = Json.text(run, "finishedAt");
                if (latest == null || nullSafe(finishedAt).compareTo(latest) > 0) latest = finishedAt;
            }
        }
        return latest;
    }
    private Json.Obj summaryJob(Json.Obj job) {
        return Json.obj()
                .set("jobKey", Json.text(job, "jobKey"))
                .set("sourceId", Json.text(job, "sourceId"))
                .set("sourceName", Json.text(job, "sourceName"))
                .set("title", Json.text(job, "title"))
                .set("company", Json.text(job, "company"))
                .set("city", Json.text(job, "city"))
                .set("url", Json.text(job, "url"));
    }

    private Json.Obj findJob(String jobKey) {
        if (jobKey == null) return null;
        Object value = map(root, "jobs").get(jobKey);
        return value instanceof Map<?, ?> ? Json.asObj(value) : null;
    }

    private Json.Obj activeWatch(String userId, String jobKey) {
        for (Object value : watchesFor(userId)) {
            Json.Obj watch = Json.asObj(value);
            if (Json.bool(watch, "active", false) && jobKey.equals(Json.text(watch, "jobKey"))) return watch;
        }
        return null;
    }

    private Json.Obj requireUser(String userId) {
        Object value = map(root, "users").get(userId);
        if (!(value instanceof Map<?, ?>)) throw new IllegalArgumentException("登录已失效，请重新登录");
        return Json.asObj(value);
    }

    private Json.Arr watchesFor(String userId) { return userList(root, "watches", userId); }
    private Json.Arr changesFor(String userId) { return userList(root, "changes", userId); }
    private Json.Arr changesForJob(String userId, String jobKey) { return changes(userId, jobKey, false); }

    private static Json.Arr userList(Json.Obj data, String collection, String userId) {
        Json.Obj all = map(data, collection);
        Object existing = all.get(userId);
        if (existing instanceof List<?>) return Json.asArr(existing);
        Json.Arr created = Json.arr();
        all.put(userId, created);
        return created;
    }

    private static Json.Obj map(Json.Obj data, String key) {
        Object value = data.get(key);
        if (value instanceof Map<?, ?>) return Json.asObj(value);
        Json.Obj created = Json.obj();
        data.put(key, created);
        return created;
    }

    private static List<String> stringList(Object value) {
        List<String> result = new ArrayList<>();
        if (value instanceof List<?>) {
            for (Object item : (List<?>) value) if (item != null) result.add(String.valueOf(item));
        }
        return result;
    }

    private static List<String> defaultSourceIds() { return List.of("remotive", "amazon"); }
    private static String safeLower(String value) { return value == null ? "" : value.toLowerCase(Locale.ROOT); }
    private static String nullSafe(String value) { return value == null ? "" : value; }

    private void save() {
        try {
            saveTo(file, root);
        } catch (IOException ex) {
            throw new IllegalStateException("无法保存数据文件: " + file, ex);
        }
    }

    private static void saveTo(Path target, Json.Obj data) throws IOException {
        Files.createDirectories(target.getParent());
        Path temporary = target.resolveSibling(target.getFileName() + ".tmp");
        Files.writeString(temporary, Json.stringify(data), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        try {
            Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}